var searchData=
[
  ['unsubscribetopics',['UnsubscribeTopics',['../class_m2_mqtt_unity_1_1_examples_1_1_m2_mqtt_unity_test.html#a36fec4325281c85348c3df2cf04e1121',1,'M2MqttUnity.Examples.M2MqttUnityTest.UnsubscribeTopics()'],['../class_m2_mqtt_unity_1_1_m2_mqtt_unity_client.html#a1be62cce65515bf0b29b2c69c45978af',1,'M2MqttUnity.M2MqttUnityClient.UnsubscribeTopics()']]],
  ['update',['Update',['../class_m2_mqtt_unity_1_1_examples_1_1_m2_mqtt_unity_test.html#ae15700034cec7894cb29bb22e214fa7b',1,'M2MqttUnity.Examples.M2MqttUnityTest.Update()'],['../class_m2_mqtt_unity_1_1_m2_mqtt_unity_client.html#a10fe0c568df107daaa611b5d72dfb94e',1,'M2MqttUnity.M2MqttUnityClient.Update()']]]
];
