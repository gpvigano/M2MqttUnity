var indexSectionsWithContent =
{
  0: "abcdeimopstu",
  1: "m",
  2: "m",
  3: "m",
  4: "acdopstu",
  5: "abcdeipt",
  6: "c",
  7: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "events",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Events",
  7: "Pages"
};

