var searchData=
[
  ['brokeraddress',['brokerAddress',['../class_m2_mqtt_unity_1_1_m2_mqtt_unity_client.html#a4ed856dd88fe099a106959cff800b5bd',1,'M2MqttUnity::M2MqttUnityClient']]],
  ['brokerport',['brokerPort',['../class_m2_mqtt_unity_1_1_m2_mqtt_unity_client.html#a6bcb116cf5a6779321aa63ca693c4d04',1,'M2MqttUnity::M2MqttUnityClient']]]
];
