var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "M2MqttUnity.M2MqttUnityClient", "class_m2_mqtt_unity_1_1_m2_mqtt_unity_client.html", [
        [ "M2MqttUnity.Examples.M2MqttUnityTest", "class_m2_mqtt_unity_1_1_examples_1_1_m2_mqtt_unity_test.html", null ]
      ] ]
    ] ]
];